package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Pantalla1() {
    Scaffold(
        topBar = {
            // Barra superior con título y botón de inicio
            TopAppBar(
                title = { Text(text = "Hogar") },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            Icons.Filled.KeyboardArrowRight,
                            "Home",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.purple_200),
                    titleContentColor = Color.White,
                ),
            )
        },
        content = { innerPadding ->
            // Contenido de la pantalla de inicio
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color.White)
            ) {
                // Sección de productos
                item {
                    ProductItem(
                        Product("Plancha","Precio:$30.00","Cantidad:150 Und","Con una superficie de " +
                                "cocción amplia y antiadherente, esta plancha permite la preparación eficiente " +
                                "de una variedad de alimentos, desde carnes y verduras hasta panes y huevos.",
                            R.drawable.plancha),
                    )
                }
                item {
                    ProductItem(
                        Product("Sillon","Precio:$20.00","Cantidad:30 Und","Descipcion: El sillón de diseño " +
                                "ergonómico no solo representa un asiento cómodo, sino también una obra maestra de elegancia y funcionalidad " +
                                "en el mundo del mobiliario. ", R.drawable.sillon),
                    )
                }
                item {
                    ProductItem(
                        Product("Cama","Precio:$50.00","Cantidad:20 Und",
                            "Descipcion: La cama de lujo que te presento redefine el " +
                                    "concepto de descanso, fusionando un diseño elegante con un confort excepcional. ",
                            R.drawable.cama)

                    )
                }

                // Espaciado entre secciones
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        },
        bottomBar = {
            // Barra inferior con información de derechos de autor y políticas
            BottomAppBar(
                containerColor = colorResource(id = R.color.purple_200),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "© CARREFOUR, S.A. \n" +
                                "COOKIES \n" +
                                "AVISO LEGAL \n" +
                                "POLÍTICA DE PRIVACIDAD ",
                        style = TextStyle(fontSize = 12.sp)
                    )
                }
            }
        }
    )
}

@Composable
private fun ProductItem(product: Product) {
    Row(
        // Fila que muestra un producto y botones de agregar/eliminar
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Image(
            // Imagen del producto
            painter = painterResource(id = product.imageResId),
            contentDescription = null,
            modifier = Modifier
                .size(120.dp)
                .clip(MaterialTheme.shapes.medium)
        )

        Column(
            modifier = Modifier
                .padding(start = 16.dp)
                .weight(1f)
        ) {
            // Nombre y precio del producto
            Text(
                text = product.name,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.precio}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.cantidad}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.descripcion}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }

    }
}
