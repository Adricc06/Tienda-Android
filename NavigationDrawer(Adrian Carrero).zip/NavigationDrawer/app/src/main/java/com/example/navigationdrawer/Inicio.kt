package com.example.navigationdrawer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.navigationdrawer.ui.theme.NavigationDrawerTheme

data class Product(val name: String ,val precio:String,val cantidad:String,val descripcion: String, val imageResId: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Pantalla0() {
    Scaffold(
        topBar = {
            // Barra superior con título y botón de inicio
            TopAppBar(
                title = { Text(text = "¡Bienvenido a nuestra tienda!") },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            Icons.Filled.Home,
                            "Arrow",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.purple_200),
                    titleContentColor = Color.White,
                ),
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Text(
                    text = "Descubre nuestras categorías:",
                    style = TextStyle(
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Hogar:" + " Encuentra productos para hacer de tu hogar un lugar más acogedor.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Electrónica: " + " Descubre las últimas novedades en tecnología y gadgets.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Ropa:" + " Viste con estilo y comodidad con nuestra selección de ropa de moda.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Cocina:" + " Equipa tu cocina con utensilios y electrodomésticos de alta calidad.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Juguetes:" + " Diviértete y estimula la imaginación con nuestros juguetes para todas las edades.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Decoración:" + " Dale un toque único a tu espacio con nuestra variedad de decoración.",
                    style = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 20.sp,
                        color = Color.Black
                    )
                )
            }
        },
        bottomBar = {
            // Barra inferior con información de derechos de autor y políticas
            BottomAppBar(
                containerColor = colorResource(id = R.color.purple_200),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "© CARREFOUR, S.A. \n" +
                                "COOKIES \n" +
                                "AVISO LEGAL \n" +
                                "POLÍTICA DE PRIVACIDAD ",
                        style = TextStyle(fontSize = 12.sp)
                    )
                }
            }
        }
    )
}


@Preview(showBackground = true)
@Composable
fun Pantalla0Preview() {
    NavigationDrawerTheme {
        Pantalla0()
    }
}
