package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Pantalla5() {
    Scaffold(
        topBar = {
            // Barra superior con título y botón de inicio
            TopAppBar(
                title = { Text(text = "Juguetes") },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            Icons.Filled.KeyboardArrowRight,
                            "Home",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.purple_200),
                    titleContentColor = Color.White,
                ),
            )
        },
        content = { innerPadding ->
            // Contenido de la pantalla de inicio
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color.White)
            ) {
                // Sección de productos
                item {
                    ProductItem(
                        Product("Dinosaurio","Precio:$250.00","Cantidad:45 Und","Descripcion: Este dinosaurio de juguete ofrece a" +
                                "los pequeños exploradores una experiencia emocionante y educativa.  ",
                            R.drawable.dinosaurio),
                    )
                }
                item {
                    ProductItem(
                        Product("Pokemon","Precio:$950.00","Cantidad:120 Und","Descripcion: Este juguete de Pokémon ofrece " +
                                "una experiencia llena de diversión y emoción para los fans de todas las edades. ", R.drawable.pokemon),
                    )
                }
                item {
                    ProductItem(
                        Product("Balón","Precio:$850.00","Cantidad:70 Und",
                            "Descripcion: Este balón de fútbol representa la excelencia en diseño y rendimiento, " +
                                    "ofreciendo una experiencia de juego superior tanto para jugadores aficionados como para " +
                                    "profesionales.",R.drawable.balon)

                    )
                }

                // Espaciado entre secciones
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        },
        bottomBar = {
            // Barra inferior con información de derechos de autor y políticas
            BottomAppBar(
                containerColor = colorResource(id = R.color.purple_200),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "© CARREFOUR, S.A. \n" +
                                "COOKIES \n" +
                                "AVISO LEGAL \n" +
                                "POLÍTICA DE PRIVACIDAD ",
                        style = TextStyle(fontSize = 12.sp)
                    )
                }
            }
        }
    )
}

@Composable
private fun ProductItem(product: Product) {
    Row(
        // Fila que muestra un producto y botones de agregar/eliminar
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Image(
            // Imagen del producto
            painter = painterResource(id = product.imageResId),
            contentDescription = null,
            modifier = Modifier
                .size(120.dp)
                .clip(MaterialTheme.shapes.medium)
        )

        Column(
            modifier = Modifier
                .padding(start = 16.dp)
                .weight(1f)
        ) {
            // Nombre y precio del producto
            Text(
                text = product.name,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.precio}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.cantidad}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.descripcion}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }

    }
}

