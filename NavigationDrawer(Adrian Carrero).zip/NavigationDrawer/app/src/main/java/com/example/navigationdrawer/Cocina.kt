package com.example.navigationdrawer


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Pantalla4() {
    Scaffold(
        topBar = {
            // Barra superior con título y botón de inicio
            TopAppBar(
                title = { Text(text = "Cocina") },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            Icons.Filled.KeyboardArrowRight,
                            "Home",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.purple_200),
                    titleContentColor = Color.White,
                ),
            )
        },
        content = { innerPadding ->
            // Contenido de la pantalla de inicio
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color.White)
            ) {
                // Sección de productos
                item {
                    ProductItem(
                        Product("Sarten","Precio:$20.00","Cantidad:30 Und","Descripcion: Construida con materiales de alta calidad, " +
                                "la sartén para tienda profesional presenta una superficie antiadherente resistente " +
                                "que facilita la preparación de una amplia variedad de alimentos con un mínimo de " +
                                "grasas y aceites.", R.drawable.sarten),
                    )
                }
                item {
                    ProductItem(
                        Product("Nevera","Precio:$700.00","Cantidad:120 Und","Descripcion: El refrigerador de última " +
                                "generación redefine la experiencia de almacenamiento de alimentos con un diseño innovador, " +
                                "tecnología avanzada y características inteligentes que optimizan la frescura y la eficiencia. ", R.drawable.nevera),
                    )
                }
                item {
                    ProductItem(
                        Product("Maquina de cocina","Precio:$50.00","Cantidad:20 Und",
                            "Descipcion: Con una combinación " +
                                    "única de funciones y un diseño elegante, esta máquina se convierte en el " +
                                    "aliado perfecto para chefs caseros y entusiastas de la cocina.",
                            R.drawable.maquina_de_cocina)

                    )
                }

                // Espaciado entre secciones
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        },
        bottomBar = {
            // Barra inferior con información de derechos de autor y políticas
            BottomAppBar(
                containerColor = colorResource(id = R.color.purple_200),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "© CARREFOUR, S.A. \n" +
                                "COOKIES \n" +
                                "AVISO LEGAL \n" +
                                "POLÍTICA DE PRIVACIDAD ",
                        style = TextStyle(fontSize = 12.sp)
                    )
                }
            }
        }
    )
}

@Composable
private fun ProductItem(product: Product) {
    Row(
        // Fila que muestra un producto y botones de agregar/eliminar
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Image(
            // Imagen del producto
            painter = painterResource(id = product.imageResId),
            contentDescription = null,
            modifier = Modifier
                .size(120.dp)
                .clip(MaterialTheme.shapes.medium)
        )

        Column(
            modifier = Modifier
                .padding(start = 16.dp)
                .weight(1f)
        ) {
            // Nombre y precio del producto
            Text(
                text = product.name,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.precio}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.cantidad}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
            Text(
                text = "${product.descripcion}",
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }

    }
}
